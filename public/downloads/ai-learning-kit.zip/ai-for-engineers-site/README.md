# AI for Engineers

从问题出发，理解 AI。面向有工程背景、缺少系统 AI 基础的学生与研究者，以问题导航、知识地图、算法图鉴和官方资源连接学习与实践。

这是独立的公共网站项目。第一版不包含私人研究训练计划、私人对话或未公开实验材料。

## 本地运行

需要 **Node.js 24 或更新版本**与 npm。下载并解压后，在 `ai-for-engineers-site` 目录打开终端：

```bash
npm ci
npm run dev
```

打开终端显示的地址（通常为 `http://localhost:4321`）。停止服务按 Ctrl+C。首次安装需要访问 npm。

```bash
npm run drafts    # 本地审阅草稿，显示草稿标记与 noindex
npm run verify    # 类型检查、生产构建、内部路径/草稿/公式验证
npm run preview   # 预览已经构建的 dist，通常为 http://localhost:4321
```

草稿预览采用跨平台 Node 脚本，适用于 macOS、Windows 与 Linux。生产构建始终过滤 `draft: true`，即使设置了 `PREVIEW_DRAFTS=true`。

## 当前内容

- 首页、入门指南、知识地图、学习路径、算法图鉴、笔记、资源与关于页面。
- 15 张方法卡片，包括监督学习、聚类、神经网络、生成建模、概率推断、优化与可靠性。
- 两张全局大图：39 个知识节点、8 个探索区域及共同基础；34 个历史节点、24 条关系与 7 条历史泳道。
- 拖动、缩放、全屏、节点侧栏与可拖动、半透明、可折叠的导航小地图；全览／聚焦／与我有关模式，路线与关系筛选。
- 放大节点细节，一键返回初始视图；关系标签独立图层并避开卡片，点击可读完整解释与例子。
- 浏览器本地保存自评学习阶段与当前位置；历史图按明确绑定突出对应工作。
- 11 类工程目标的条件选型：同时显示简单基线、候选方法、适用边界与评价建议。
- 三篇基础教程，附交互演示与可运行的 Python 示例。
- 12 项带先修与选读建议的官方/社区入口。
- 5 篇编辑草稿，仅在本地草稿预览显示。
- 全站客户端搜索、类别/关键词筛选、深浅色主题与移动导航。
- Markdown / MDX、公式（KaTeX）、代码高亮、目录、相关内容。
- 静态 SEO 元数据、sitemap、robots 与 GitHub Pages 自动部署配置。

没有服务端、账号系统、分析追踪或收费依赖。搜索索引在构建时生成；主题偏好只保存在访客浏览器中。

## 技术与结构

Astro 7、TypeScript、Content Collections、Markdown / MDX、纯 CSS。所有运行依赖由 `package-lock.json` 锁定。

| 文件/目录 | 修改内容 |
| --- | --- |
| `src/config.ts` | 作者、标题、简介、真实 GitHub 链接 |
| `src/pages/` | 首页、地图、入门、路径等固定页面 |
| `src/content/articles/` | 通用教程与个人学习日志 |
| `src/content/algorithms/` | 算法卡片 |
| `src/content/resources/*.md` | 独立的资源条目与核查日期 |
| `src/data/history/raw/` | 用户提供的原始历史数据与说明，保留导入原貌 |
| `src/data/history/editorial.json` | 节点类型、精选标记、方法绑定、参考标签 |
| `src/data/history/relations.ts` | 关系语义与年份口径标签 |
| `src/content/algorithms/` 与 `src/content/concepts/` | 唯一概念作者文件：元数据、正文、基础与历史绑定 |
| `src/data/knowledge/` | 共享资源、分区、概念关系及生成投影 |
| `src/data/learning/` | 学习单元与多条精选路径，使用概念与资源 ID |
| `src/data/knowledge-map.ts` | 兼容视图；不在这里重复维护概念 |
| `src/data/knowledge-relations.ts` | 16 条概念联系的短提示、完整句与例子 |
| `src/data/learning/units.json` / `paths.json` | 33 个共享单元、两条精选路径、前置与并行/选修 |
| `src/content/algorithms/*.md` / `concepts/*.md` | 单一概念源；名称、摘要、引用 ID、绑定与正文 |
| `src/lib/path-layout.mjs` / `src/lib/path-routing.mjs` | 二维泳道布局、拓扑层级与连线避障 |
| `src/scripts/path-graph.ts` | 课程图镜头、筛选、关系与小地图 |
| `src/lib/history-layout.mjs` | 年份区间、泳道与卡片防重叠布局 |
| `src/scripts/global-map.ts` | 缩放、侧栏、自评学习阶段与定位 |
| `src/data/engineering.ts` | 工程问题与方法、历史节点、实验的映射 |
| `src/data/engineering-profiles.ts` | 11 类工程任务的基线与评价建议 |
| `src/lib/engineering-selector.mjs` | 公开的条件选型规则 |
| `src/data/map-resources.ts` | 知识区域与现有课程资料的绑定 |
| `src/content.config.ts` | 元数据校验规则 |
| `src/styles/global.css` | 配色、字体、布局与响应式样式 |
| `templates/` | 三种写作模板，不进入网站构建 |
| `scripts/` | 部署配置与验证脚本 |
| `.github/workflows/deploy.yml` | 构建和 GitHub Pages 部署 |

## 添加内容

### 文章

复制 `templates/article.md` 到 `src/content/articles/your-slug.md`，更新标题、日期、说明、标签与参考资料。个人日志使用 `templates/journal.md`，设置 `kind: journal`。

`date` 是文章发布日期，`updated` 是修订日期。`draft` 默认 true。用 `npm run drafts` 审阅，确认后改为 `draft: false`，再运行 `npm run verify`。文章路径由文件名生成。

### 算法卡片

复制 `templates/algorithm.md` 到 `src/content/algorithms/your-slug.md`；将 `detailConceptId` 与文件名 ID 对齐，选择分区与基础概念，在注册表添加或复用 `referenceIds`。填写任务、动机、核心思想、假设、优势、局限、应用、替代方法与最小实践。新公开概念还需学习单元绑定和地图布局验证；检查来源后再发布。

### 资源

先在 `src/data/knowledge/resources.json` 添加或复用资料 ID 与 URL，再复制 `templates/resource.md` 到 `src/content/resources/<英文文件名>.md`。指南通过 `resourceId` 引用唯一 URL；填写提供者、类别、先修知识、选读入口、真实核查日期、`coding` 和 `media`。`verified` 只表示该日能访问页面，不表示已完成课程或赞同全部内容。

### 内部链接

Astro 文件统一通过 `href()` 生成带 base 的链接。文章中的站内链接优先使用相对于文章路径的 URL，例如 `../../atlas/regression/`。不要在 Markdown 里硬编码 `/atlas/...`，否则仓库子路径部署会丢失 base。外部资料使用完整 HTTPS URL。

```md
行内公式：$\hat y = w^\top x + b$

$$
L = \frac{1}{n}\sum_i (y_i - \hat y_i)^2
$$
```

代码使用带语言标记的 fenced code block。MDX 可导入组件，但普通文章优先使用 Markdown。

## 部署到 GitHub Pages

1. 建立 GitHub 仓库。个人主页仓库命名为 `你的用户名.github.io`；普通项目仓库可命名为 `ai-for-engineers`。
2. 将本项目目录中的文件作为仓库根目录，包括 `.github/`、`package.json` 和锁文件。不要把 `node_modules` 或 `dist` 提交进去。
3. 把默认分支设为 `main`，在 **Settings → Pages → Build and deployment → Source** 选择 **GitHub Actions**。
4. 提交代码后，工作流检查、构建和上传；部署成功后的 URL 出现在 Actions 与 Pages 设置中。

工作流根据 Pages 配置自动推断 origin 与 base，不写死用户名。`username.github.io` 使用根目录，普通项目使用 `/repository-name`。自定义域名可通过仓库变量 `SITE_URL` 与 `BASE_PATH` 覆盖（`BASE_PATH` 设为 `/`），并按 GitHub 官方指引配置域名与 `public/CNAME`。

本地模拟两种路径（示例用户名仅用于测试）：

```bash
GITHUB_REPOSITORY=TestUser/TestUser.github.io npm run verify
GITHUB_REPOSITORY=TestUser/guide npm run verify
```

Windows PowerShell：

```powershell
$env:GITHUB_REPOSITORY = "TestUser/guide"
npm run verify
Remove-Item Env:GITHUB_REPOSITORY
```

如不设置站点域名，本地构建不会输出虚构 canonical URL。GitHub 构建会填入真实域名并生成完整 sitemap。

参考：[Astro 官方 GitHub Pages 部署](https://docs.astro.build/en/guides/deploy/github/) · [Content Collections](https://docs.astro.build/en/guides/content-collections/)。

## 验证与局限

`npm run verify` 校验类型、主要路由、站内链接和锚点、资源引用、搜索索引、草稿排除、公式渲染及部署配置。`npm run check:links` 请求外部页面并生成 `external-link-report.json`，网络限制与反机器人响应需人工辨别，不能直接当作失效链接。

见 `VALIDATION.md` 了解本次实际执行结果。GitHub Actions 的远程运行需要真实仓库；本项目交付不等于已发布。仍需在浏览器中检查桌面/手机排版、主题、导航与搜索交互。

## 常见问题

- **Node 版本错误**：检查 `node --version`，安装 Node 24 LTS 或更新版本。
- **安装失败**：检查 npm 网络访问；锁文件与 npm 版本应匹配，使用 `npm ci`。
- **Pages 资源 404**：确认仓库根目录和 Pages 配置，检查 `BASE_PATH` 是否被错误覆盖。
- **文章不出现**：检查 `draft`、文件目录、frontmatter 与构建报错。本地可用 `npm run drafts`。
- **公式不显示**：保留 `@astrojs/markdown-remark`、`remark-math`、`rehype-katex` 与 KaTeX 样式。
- **工作流没触发**：检查默认分支是否为 `main`，或从 Actions 手动运行 workflow。
- **站内搜索没结果**：先重新构建，检查 `search-index.json`；搜索默认不索引未发布草稿。

## 维护

写作原则见 `CONTENT_GUIDE.md`，协作流程见 `CONTRIBUTING.md`。先更新内容与参考，再扩大交互功能。依赖升级后重新验证根目录与子路径。

## 当前版本与运营

三篇基础教程含网页演示和标准库 Python 示例；地图默认展示全部节点；点击节点在侧栏展开详情，支持两图跳转。知识图按自评标记学习阶段，历史图按年份区间分列。历史原始包不等于完整审稿；详情页区分导入核查记录与本次结构检查。学习勾选保存在当前浏览器。资源库按主题、难度、编程要求和形式筛选。

GitHub 网页添加内容的步骤见 [MAINTAINING.md](MAINTAINING.md)。仓库存在后，在 `src/config.ts` 设置 `repositoryUrl`，启用源码、编辑与勘误入口。预览不代表已经部署到 GitHub Pages。

## Learning Path · 二维学习路径

`src/data/learning-path.json` 是自动生成的兼容视图；33 个选读单元在 `src/data/learning/units.json` 维护：稳定 ID、前置 ID、对应知识点、资料链接/语言/选读范围、估计时间和自查任务。四个小关从 5、8、10、15 分钟起步；共同基础后选择平级分支。时间指编辑安排的选读任务，不是原课程完整时长。

`src/lib/storage/progress.mjs` 与 `progress-store.ts` 管理版本化本地记录，包含 not_started / in_progress / completed / already_known、selectedPath 和 updatedAt。`zeno-learning-path-v1` 的 done / prior 只读迁移为新记录。它与旧实验勾选、自评阶段分开保存。有效记录点亮显式绑定知识点，不自动提高“能解释”“能实践”。撤销前置保留下游记录为待复核，补回后恢复。直接展开的二维课程图和每关的前置链接帮助定位顺序，资料无需解锁即可访问。知识地图仅绘制概念联系，39 个节点均提供外部资料及对应关卡；历史图保持 34/24 原数据。

`npm run verify` 包含关卡 DAG、资源覆盖、状态解析、前置开放、平行分支、已有基础与撤销恢复的验证；真实浏览器交互范围见 VALIDATION.md。

完整课程图采用 9 个学习方向泳道、40 条前置箭头；平级神经架构对齐，课程连线绕开其他卡片。支持搜索、方向筛选、当前前置链、缩放、起步聚焦与可移动小地图。课程与 39 个知识节点统一 English-first / 中文辅助；英文全称、简称和中文均可用于搜索。设计调研、来源与取舍见 [CURRICULUM_DESIGN.md](CURRICULUM_DESIGN.md)。


## Local MVP · 单一知识库与多条路径

本轮源码在 `feature/unified-knowledge-paths` 分支开发；**没有推送或部署**，线上预览保持上一版。新增 `/learn/engineering-ai-foundations/`（8 单元，7 必修 + 1 选修）和 `/learn/engineering-optimization/`（7 单元，6 必修 + 1 选修）。原 `/learn/#level-*`、`/map/`、`/atlas/*` 等地址保留。

概念元数据和正文每项只有一个 Markdown 作者文件；15 项仍位于 `src/content/algorithms`，24 项导航概念位于 `src/content/concepts`。Astro `concepts` 是 canonical collection，`algorithms` 只投影同一批作者文件供旧路由使用。`resources.json` 去重维护 85 个 URL；学习单元只引用概念/资源 ID，学习路径只引用单元 ID。`sync:data` 生成旧图/脚本所需的兼容 JSON，predev/precheck/prebuild 自动同步并验证，禁止手动编辑 generated 文件。

新进度 key 为 `ai-for-engineers.progress.v1`。不同路径共享单元记录；JSON 导入支持合并/替换，验证失败保留原状态。重置可撤销，旧键不会被删掉或自动反复导入。独立能力自评不因选读完成而升级，也不包含在课程进度 JSON 导出中。跨浏览器靠文件转移，完全没有账户或云同步。

精确编辑入口、数据迁移与实际验收见 `docs/ARCHITECTURE_AUDIT.md`、`docs/CONTENT_WORKFLOW.md`、`docs/PROVENANCE.md`、`docs/MVP_ACCEPTANCE.md`。
